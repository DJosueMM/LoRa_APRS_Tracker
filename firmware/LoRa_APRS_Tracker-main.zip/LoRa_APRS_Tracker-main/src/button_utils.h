#ifndef BUTTON_UTILS_H_
#define BUTTON_UTILS_H_

#include <Arduino.h>

namespace BUTTON_Utils {

    void singlePress();
    void longPress();
    void doublePress();
    void multiPress();

}

#endif